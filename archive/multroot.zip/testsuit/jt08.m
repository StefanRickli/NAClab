function [p,z] = jt08
%
%  test polynomial suggested by Jenkins and Traub
%
   p = poly([-1,-1,-1,-1,-1]);
   z = [-1, 5];
   fprintf('                 roots         multiplicities\n');
        fprintf('\n');
        fprintf('%25.15f \t \t \t %3g \n', z');
   