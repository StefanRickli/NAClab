function p = twin03()

   k = 12;
   p = poly([-0.2*ones(1,k),0.39*ones(1,k),0.40*ones(1,k)])