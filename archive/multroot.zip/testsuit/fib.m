function p = fib(n)
%
%  test polynomial suggested by Goedecker
%
    p = [-1,ones(1,n)];