%  Compute the total or tuple degree of a multivariate polynomial p
%
%    Syntax:  >> d = mvPolynDegree(p,'total')
%             >> d = mvPolynDegree(p,'tuple')
