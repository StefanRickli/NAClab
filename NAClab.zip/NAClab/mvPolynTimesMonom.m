%  Compute a multivariate polynomial p times a monomial t
%
%    Syntax:  >> f = mvPolynTimesMonom(p,t)
