%  generate a pair of nxn integer matrices that are inverse to each other 
%
%  syntax  >> [X,Y] = IntegerInverse(n)
%          >> [X,Y] = IntegerInverse(n,m)  % entries in interval [-m,m]
