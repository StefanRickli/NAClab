%  computing the Householder transformation  w = v*H  with 
%            H = I - 2*u*u' 
%
%  syntax  >> w = HouseholderTransformRight(u,v)
