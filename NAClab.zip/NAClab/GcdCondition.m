%
% Compute the GCD condition number from given GCD triplet (u,v,w)
%
% Syntax:  >> cond = GcdCondition(u,v,w)
