%  generate a random matrix of  mxn  with integer entries from  a  to  b
%
%  syntax  >> K = irand(m,n,a,b)