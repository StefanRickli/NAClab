%  generate a random matrix of  mxn  with integer entries from  a  to  b
%
%  syntax  >> K = Irand(m,n,a,b)  % with all 4 input argument
%          >> K = Irand(m,n)      % same as Irand(m,n,-9,9)
%          >> K = Irand()         % same as Irand(1,1,-9,-9)
