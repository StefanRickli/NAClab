%  generate a random mxn matrix with entries in [-1,1]
%
%  syntax  >> A = Srand(m,n)